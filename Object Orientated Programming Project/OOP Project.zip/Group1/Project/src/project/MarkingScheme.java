/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.Serializable;

/**
 *
 * @author Liam
 */
public class MarkingScheme implements Serializable{
    private String gradeA = "";
    private String gradeB = "";
    private String gradeC = "";
    private String fullMarkA = "";
    private String fullMarkB = "";
    private String fullMarkC = "";
    private String examMarkA = "";
    private String examMarkB = "";
    private String examMarkC = "";
    private String markA = "";
    private String tipsA = "";
    private String timeA = "";
    private String markB = "";
    private String tipsB = "";
    private String timeB = "";
    
    public void setGradeA(String gradeA){
        this.gradeA = gradeA;
    }
    public void setGradeB(String gradeB){
        this.gradeB = gradeB;
    }
    public void setGradeC(String gradeC){
        this.gradeC = gradeC;
    }
    public void setExamMarkA(String examMarkA){
        this.examMarkA = examMarkA;
    }
    public void setExamMarkB(String examMarkB){
        this.examMarkB = examMarkB;
    }
    public void setExamMarkC(String examMarkC){
        this.examMarkC = examMarkC;
    }
    public void setFullMarkA(String fullMarkA){
        this.fullMarkA = fullMarkA;
    }
    public void setFullMarkB(String fullMarkB){
        this.fullMarkB = fullMarkB;
    }
     public void setFullMarkC(String fullMarkC){
        this.fullMarkC = fullMarkC;
    }

    public String getGradeA() {
        return gradeA;
    }

    public String getGradeB() {
        return gradeB;
    }

    public String getGradeC() {
        return gradeC;
    }

    public String getFullMarkA() {
        return fullMarkA;
    }

    public String getFullMarkB() {
        return fullMarkB;
    }

    public String getFullMarkC() {
        return fullMarkC;
    }

    public String getExamMarkA() {
        return examMarkA;
    }

    public String getExamMarkB() {
        return examMarkB;
    }

    public String getExamMarkC() {
        return examMarkC;
    }

    public String getMarkA() {
        return markA;
    }

    public void setMarkA(String markA) {
        this.markA = markA;
    }

    public String getTipsA() {
        return tipsA;
    }

    public void setTipsA(String tipsA) {
        this.tipsA = tipsA;
    }

    public String getTimeA() {
        return timeA;
    }

    public void setTimeA(String timeA) {
        this.timeA = timeA;
    }

    public String getMarkB() {
        return markB;
    }

    public void setMarkB(String markB) {
        this.markB = markB;
    }

    public String getTipsB() {
        return tipsB;
    }

    public void setTipsB(String tipsB) {
        this.tipsB = tipsB;
    }

    public String getTimeB() {
        return timeB;
    }

    public void setTimeB(String timeB) {
        this.timeB = timeB;
    }

    int getSumA() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getSection1() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getSection2() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    int getSumB() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getSection3() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    int getGrade3() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setGrade1(int grade1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setGrade2(int grade2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setGrade3(int grade3) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    int getGrade1() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    int getGrade2() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setTips(String htmlAnswer_five_questions_from_this_secti) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setMark(String _Marks) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setTiming(String html90_minutes_for_5_questions_5_minutes_) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setSection(String section_B) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getMark() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getTips() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getTiming() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getSection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}


